from pathlib import Path
import subprocess,json,hashlib,shutil,sys
R=Path(r'E:\Github\yammerknit');V=R/'verification/estate-quality-20261007';C=V/'checkout-r1'
if C.exists():raise SystemExit('Preserve prior checkout evidence')
C.mkdir();stage=C/'index-source';stage.mkdir();checkout=C/'checkout';checkout.mkdir()
paths=set(json.loads((V/'baseline.json').read_text('utf-8'))['source_inventory'])
paths.update(p.relative_to(R).as_posix() for folder in (R/'skills/yammerknit',R/'delivery-sidecars/estate-quality-20261007-r1',R/'verification/hesperos-capabilities',V/'authorship') for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths.add('verification/test_estate_release.py')
inputs={rel:hashlib.sha256((R/rel).read_bytes()).hexdigest() for rel in sorted(paths)}
(V/'maintained-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8',newline='\n')
issues=[]
for rel in sorted(paths):
 src=R/rel;dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
 raw=subprocess.check_output(['git','hash-object','--no-filters',rel],cwd=R,text=True).strip()
 filtered=subprocess.check_output(['git','hash-object','--path',rel,rel],cwd=R,text=True).strip()
 if raw!=filtered:issues.append(rel)
if issues:raise SystemExit('Git representation differs: '+str(issues))
for args in (['git','init','--quiet'],['git','config','core.autocrlf','false'],['git','add','--all'],['git','checkout-index','--all','--prefix',str(checkout).replace('\\','/')+'/']):
 subprocess.run(args,cwd=stage,check=True,capture_output=True)
for rel in sorted(paths):
 if (checkout/rel).read_bytes()!=(R/rel).read_bytes():issues.append(rel)
result=subprocess.run([sys.executable,'-B','-X','utf8',str(checkout/'verification/build_release.py'),'--repo',str(checkout),'--output-dir',str(C/'rebuilt')],capture_output=True,text=True,encoding='utf-8');(C/'build.json').write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n');assert result.returncode==0,result.stderr
candidate=R/'release-candidates/estate-quality-20261007-r1/Yammerknit-v0.1.0.zip';rebuilt=C/'rebuilt/Yammerknit-v0.1.0.zip'
assert candidate.read_bytes()==rebuilt.read_bytes(),'Checkout rebuilt bytes differ'
report={'maintained_files':len(paths),'git_filtered_exact':not issues,'fresh_checkout_exact':not issues,'rebuild_exact':True,'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'issues':issues,'scope':'Isolated Git index/checkout; canonical repository index and history unchanged.'}
(V/'git-checkout-r1.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report,indent=2))
