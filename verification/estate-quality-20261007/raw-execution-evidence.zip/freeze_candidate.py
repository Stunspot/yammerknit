from pathlib import Path
import json,hashlib,zipfile,subprocess
R=Path(r'E:\Github\yammerknit');V=R/'verification/estate-quality-20261007';A=V/'product-audit'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
baseline=json.loads((V/'baseline.json').read_text('utf-8'));inputs=json.loads((V/'maintained-inputs.json').read_text('utf-8'))
assert all(sha(R/p)==digest for p,digest in inputs.items())
with zipfile.ZipFile(V/'baseline-source.zip') as z:
 preserved=[p for p in baseline['source_inventory'] if p.startswith('assets/') or p.startswith('docs/assets/') or p in ('skills/yammerknit/references/canonical-sop.md','skills/yammerknit/personas/canonical-rupert-giles-document-guardian.txt') or (p.startswith('verification/') and p not in ('verification/audit_release.py','verification/browser_review.cjs','verification/build_release.py','verification/render_site_assets.cjs','verification/test_release.py','verification/test_site.py'))]
 assert all((R/p).read_bytes()==z.read(p) for p in preserved)
assert sha(R/'release/0.1.0/Yammerknit-v0.1.0.zip')==baseline['accepted_shelf_sha256']
write(V/'preservation-check.json',{'preserved_baseline_files':preserved,'count':len(preserved),'all_exact':True,'historical_release_sha256':baseline['accepted_shelf_sha256'],'live_corpus_access':'none','artwork_generated':False})
findings=json.loads((A/'findings.json').read_text('utf-8'))
proof={
'YK01':['skills/yammerknit/SKILL.md','references/source-grounding.md','product-audit/expert-continuations.md'],
'YK02':['skills/yammerknit/examples/pilot-source.txt','skills/yammerknit/examples/pilot-yammerknit.md','product-audit/expert-continuations.md'],
'YK03':['skills/yammerknit/examples/README.md','skills/yammerknit/references/source-grounding.md'],
'YK04':['skills/yammerknit/tests/test_estate_repairs.py','native-r1/extracted-runtime-tests.txt'],
'YK05':['retained-fixture-readback.json','skills/yammerknit/tests/test_estate_repairs.py'],
'YK06':['skills/yammerknit/tests/test_estate_repairs.py','retained-fixture-readback.json'],
'YK07':['skills/yammerknit/tests/test_estate_repairs.py','verification/test_estate_release.py'],
'YK08':['skills/yammerknit/tests/test_estate_repairs.py','retained-fixture-readback.json'],
'YK09':['skills/yammerknit/tests/test_estate_repairs.py','skills/yammerknit/tests/test_transcript_acquisition.py'],
'YK10':['skills/yammerknit/tests/test_native_journey.py','skills/yammerknit/references/youtube-transcripts.md'],
'YK11':['skills/yammerknit/tests/test_native_journey.py','browser-r1/browser-review.json'],
'YK12':['skills/yammerknit/examples/README.md','native-r1/extracted-runtime-tests.txt','browser-r1/browser-review.json'],
'YK13':['customer-docs/TROUBLESHOOTING.md','skills/yammerknit/tests/test_native_journey.py'],
'YK14':['native-r1/package-audit.json','git-checkout-r1.json','verification/test_estate_release.py'],
'YK15':['browser-r1/browser-review.json','package-site-tests-final.txt','authorship/documentation-authorship.json'],
'YK16':['native-r1/extracted-runtime-tests.txt','package-site-tests-final.txt','product-audit/expert-continuations.md'],
'YK17':['verification/render_site_assets.cjs','preservation-check.json']}
for finding in findings['findings']:
 finding['status']='repaired-candidate-awaiting-independent-review';finding['repair_evidence']=proof[finding['id']]
write(A/'findings.json',findings)
changed={p:{'before':baseline['source_inventory'].get(p),'after':d} for p,d in inputs.items() if baseline['source_inventory'].get(p)!=d}
write(V/'source-delta.json',changed)
(A/'repair-log.md').write_text('''# Yammerknit restoration repair log

Accepted baseline: source HEAD 05375215754ad24c0b64e7eb35af0aa44abaa5df, version 0.1.0, accepted ZIP a75eccaccff81ac5558fc79a1e62f728464b76c680e997242bd824864cfc0dd4. The initial checkout had no product changes. Baseline source, original shelf ZIP and eleven concrete failing cases were retained before repair. The critique and edit decision preceded canonical edits; YK17 was added before changing the asset helper.

The active adapter preserves the creative representation while making source authority, scientific claims, persona use, inference, unsupported transfer and completion explicit. A complete fictional pilot source, artifact and standalone chunk demonstrate the exact causal and population limits, with useful source-grounded questions and answers. The preserved canonical SOP/persona remain byte-identical.

Native custody now verifies stored source and artifact bytes, receipts, new source bindings and a single complete parent chain. Legacy missing source bindings remain labeled; they are not invented. IDs and file names are portable single components, and links/reparse ancestors are rejected before resolution. Artifact validation and persistence share one snapshot; record locks and staged publication protect ordinary concurrent/recoverable writes. Integrity checks do not claim signed authenticity or resistance to a hostile filesystem actor.

Subtitle projection retains start/end ranges, voice/language labels and repeated distinct cues. Invalid or reversed timing fails. The acquisition route rejects playlist/channel/credential URLs, joins video and selected language identity, rejects audiovisual or ambiguous output, and withholds raw failure logs. Manual/automatic caption provenance remains unknown unless separately established. No live acquisition was run.

Mesh validation now checks every bridge's endpoints and type/effect/value, actual cluster titles, defined sigils and code-fence integrity. One honest cluster is supported; prose-count guidance warns instead of manufacturing padding. This is structural validation, with semantic review explicitly separate.

Customer and site journeys now expose the actual source/artifact, meaningful first task, no-query return inventory, exact commands, preserved-history recovery and current evidence boundaries. The Codex kit includes its own coherent local marketplace. Rebuild source is included. Builders reject linked/nonportable inputs, publish a complete new output atomically and preserve existing destinations. Audits take explicit paths, reject malformed raw JSON, compare actual inventories/hashes and nested runtime parity, and never rewrite historical receipts through --help. The maintainer image helper requires a new preview output; no art was regenerated.

Verification: 43 runtime tests passed from fresh Windows extraction. Twenty package/site tests completed with nineteen passes and one Windows-only fixture limitation: a faithfully named reserved file cannot be created using the ordinary Windows API; the lexical check is exercised on POSIX CI. The Windows source-junction controls passed. Native customer and nested Claude extraction passed; the package audit checked 83 files with zero issues. Both the extracted-source rebuild and an isolated exact Git checkout rebuild reproduce the candidate ZIP byte for byte. Eighty-nine maintained files retain exact Git representation. Source and package Markdown links passed. Actual Edge desktop/mobile checks and first-example → browse/return → recovery → home navigation passed. A mobile screenshot was inspected; no horizontal overflow or clipped page content was observed.

Documentation: Hesperos in-process authorship binds 24 new/materially revised documents. Authorship validation reports zero findings. Bounded Markdown lint reports one directional-reference advisory in the worked tutorial (“source comparison above”); manual review confirms it refers to the immediately preceding named source comparison in the same tutorial and does not block the task. No accessibility conformance or independent reviewer verdict is inferred from this lint.

Historical original failure fixtures remain unchanged; current read-only inspection rejects all five retained corrupt/path/receipt cases. New mechanism-specific tests cover the remaining subtitle, URL, substitution and representation failures with adjacent valid controls. Expert authored continuations are recorded separately, with executed model trials = 0 and participant studies = 0.

Exact changed paths/hashes are in source-delta.json; exact maintained inputs are in SOURCE-FREEZE.json. All current source/artifact/sidecar bytes are frozen for root review. Central shelf, installed copies, edition consumers, board, live corpora, remote and public delivery remain root-owned and were not changed by this worker. The isolated documentation server was stopped after its browser task.
''',encoding='utf-8',newline='\n')
candidate=R/'release-candidates/estate-quality-20261007-r1/Yammerknit-v0.1.0.zip';side=R/'delivery-sidecars/estate-quality-20261007-r1'
runtime={p.relative_to(R/'skills/yammerknit').as_posix():sha(p) for p in (R/'skills/yammerknit').rglob('*') if p.is_file() and 'tests' not in p.relative_to(R/'skills/yammerknit').parts and '__pycache__' not in p.parts}
freeze={'schema':'estate-source-freeze/v1','product':'yammerknit','version':'0.1.0','treatment':'edit','state':'candidate-awaiting-independent-root-review','source_root':str(R),'maintained_files':inputs,'runtime_files':runtime,'runtime_file_count':len(runtime),'candidate':str(candidate),'candidate_sha256':sha(candidate),'sidecars':{p.name:sha(p) for p in sorted(side.iterdir())},'preserved_originals':str(V/'preservation-check.json'),'cutoff_rule':'Do not alter listed bytes; root owns acceptance/delivery. Scratch native extraction/Git checkout directories are isolated evidence and not additional product sources.'}
write(V/'SOURCE-FREEZE.json',freeze)
delivery={'product':'yammerknit','version':'0.1.0','classification':'same-version restoration edit','candidate':str(candidate),'candidate_sha256':sha(candidate),'customer_root':str(candidate.parent/'yammerknit-v0.1.0'),'source_root':str(R),'canonical_skill':str(R/'skills/yammerknit/SKILL.md'),'source_freeze':str(V/'SOURCE-FREEZE.json'),'source_freeze_sha256':sha(V/'SOURCE-FREEZE.json'),'source_inventory_count':len(inputs),'runtime_file_count':len(runtime),'sidecars':{p.name:{'path':str(p),'sha256':sha(p)} for p in sorted(side.iterdir())},'report_root':str(A),'authorship_receipt':str(V/'authorship/documentation-authorship.json'),'evidence':{'runtime':'43/43 from fresh native extraction','package_site':'19 PASS, 1 platform fixture skip','native_audit':'83 files, 0 issues','browser':'desktop/mobile and actual first-task/reentry/recovery navigation PASS','rebuild':'exact from customer source and fresh Git checkout','git':'89 maintained inputs exact','model_trials':0,'participant_trials':0},'consumers':{'declared':[],'observed':[],'installed_standalone_lead':r'C:\Users\user\.codex\plugins\cache\personal\yammerknit\0.1.0\skills\yammerknit','historical_discovery_only':[r'E:\Github\nova-emergent\working\codex\nova-emergent\skills\yammerknit',r'E:\Github\nova-emergent\working\claude\skills\yammerknit'],'instruction':'Apply current ownership inventory. Older working mirrors alone do not establish a current edition consumer; root resolves any later evidence.'},'root_actions':['Independently challenge frozen candidate and source','Accept complete ZIP plus source-owned prompt/Extra and unchanged governed avatar','Update applicable standalone installation, existing repository/release surfaces, shelf and Library under root transaction','Keep frozen accepted release history; publish/promote repaired same-version bytes through the existing current delivery surface without erasing history','Carry current documentation authorship and exact source cutoff into remote custody'],'currentness_boundary':'Candidate frozen, not yet accepted or installed by this worker. Existing historical verification records remain historical; repair evidence is in this dated directory.','residual_limits':['No fresh host-model trial or Claude activation','No live YouTube acquisition or retrieval benchmark','No participant study or assistive-technology conformance claim','Hash consistency is not signed authenticity or hostile-filesystem protection']}
write(A/'delivery.json',delivery)
print(json.dumps({'candidate_sha256':sha(candidate),'source_freeze_sha256':sha(V/'SOURCE-FREEZE.json'),'source_files':len(inputs),'runtime_files':len(runtime),'findings':len(findings['findings']),'changed_files':len(changed)},indent=2))
